SurveyBerry Java Software
-------------------------------

Contents :
Sberry jar file
.bry sample code for survey
.bat file sample
---------------------------------
Check website Home Page for information to use the files.
